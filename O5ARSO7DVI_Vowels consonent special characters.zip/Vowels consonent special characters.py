# the input will be a single line containing a string s.
inputString = input()
vowels = 0
consonents = 0
inputString = inputString.lower()
for l in inputString:
    #chack if the letter of the string is vowerls 
    if (l == 'a' or l == 'e' or l == 'i' or l == 'o' or l == 'u' ):
        vowels += 1
    else:
        #check if the letter of the string is consonant
        if l != " " and l.isdigit() == False:
            consonents += 1
        # the first line of output should contain no of vowels in the given stringinputString
print(str(vowels))
print(str(consonents))