i = input()
# if temperature is in kelvin
if i[-1] == "k" or i[-1] == "K":
    x = int(i[:-1])
    c = x - 273
    k = x
    f = (9*c/5) + 32
    print("Temperature in Celcius is :",c," C") 
    print("Temperature in Kelvin is :",k," K") 
    print("Temperature in Fahrenheit is :",f," F") 


# if temperature is in celcius    
if i[-1] == "c" or i[-1] == "C":
    x = int(i[:-1])
    c = x
    k = x + 273
    f = (9*c/5) + 32
    print("Temperature in Celcius is :",c,"C") 
    print("Temperature in Kelvin is :",k," K") 
    print("Temperature in Fahrenheit is :",f," F") 


# if temperature is in fahrenheit
if i[-1] == "f" or i[-1] == "F":
    x = float(i[:-1])
    c = (x-32)*5/9
    k = c + 273
    f = x
    print("Temperature in Celcius is :",c," C") 
    print("Temperature in Kelvin is :",k," K") 
    print("Temperature in Fahrenheit is :",f," F")