#For example, if the given N is 3, and the given matrix is
#1 2 3
#4 5 6
#7 8 9
#The anti diagonal elements of the above matrix are 3, 5, 7. So the output should be the list
#[3, 5, 7]

n = int(input())
a = []
for i in range(n):
    b = list(map(int, input().split()))
    a.append(b[n - 1 - i])
            
print(a)