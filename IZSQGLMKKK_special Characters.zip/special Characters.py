import string
vowels = set('AEIOUY')
consonants = set(string.ascii_uppercase)
consonants -= vowels
line = input().upper()
num_vow = 0
num_cons =0
for ch in line:
    if ch in vowels:
        num_vow += 1
    if ch in consonants:
        num_cons += 1
print(num_vow)
print(num_cons)