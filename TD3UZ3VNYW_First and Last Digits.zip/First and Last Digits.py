#For example, if the given numbers are M is 5 and N is 30, the numbers which have 30the first and last digit equal in the given range (5, 6, ..., 29, 30) are 5, 6, 7, 8, 9, 11 and 22. So the output should be 7.



# simple program First and Last Digits
# int(str(number)[0]) -its first digital number
# number % 10 - -its last digital number
def main():
    n = int(input(''))
    m = int(input(''))
    total = 0 
    for i in range (n, m+1):
        if int(str(i)[0]) == i % 10:
            total += 1
    print (f'{total} ')

if __name__ == "__main__":
    main()