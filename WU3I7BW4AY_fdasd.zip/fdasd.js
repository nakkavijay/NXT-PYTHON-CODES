let counterElement = document.getElementById("counterValue");
console.log(counterValue);



function onIncrement() {
    // body...
}

function onIncrement() {
    // body...
}

function onIncrement() {
    // body...
}