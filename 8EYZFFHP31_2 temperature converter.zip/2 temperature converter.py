values = input()
temperature = float(values[:-1])
scale = values[-1]
Celsius = temperature
Fahrenheit = temperature
Kelvin = temperature

if scale.upper() == "C":
    Kelvin = Celsius + 273
    Fahrenheit = (Celsius * 1.8) + 32
    print("{:.1f}C".format(round(Celsius,2)))
    print("{:.1f}F".format(round(Fahrenheit,2)))
    print("{:.1f}K".format(round(Kelvin,2)))
    
elif scale.upper()=='F':        
    #Calculate Kelvin temperature
    Kelvin=(Fahrenheit - 32) * 5/9 + 273
    #Calculate Celsius temperature
    Celsius=(Fahrenheit - 32) * 5/9
    print("{:.2f}C".format(round(Celsius,2)))
    print("{:.1f}F".format(round(Fahrenheit,5)))
    print("{:.2f}K".format(round(Kelvin,2)))
    
elif scale.upper()=='K':
    #Calculate Fahrenheit temperature
    Fahrenheit=(Kelvin - 273) * 9/5 + 32
    #Calculate Celsius temperature
    Celsius= Kelvin - 273
    print("{:.1f}C".format(round(Celsius,2)))
    print("{:.1f}F".format(round(Fahrenheit,5)))
    print("{:.1f}K".format(round(Kelvin,2)))